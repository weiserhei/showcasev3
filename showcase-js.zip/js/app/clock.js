/**
 * Clock timer
 *
 * Todo: multiple instances when needed. They can cause issues with eachother
 *
 */
define(['three'], function (THREE){

    return new THREE.Clock();

});