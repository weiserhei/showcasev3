/**
 * Setup the scene
 */
define(["three"], function (THREE){

    'use strict';

	// SCENE
	var scene = new THREE.Scene();
	//scene.fog = new THREE.Fog( 0xafafaf, 10, 15 );
	// scene.fog = new THREE.Fog( 0x556699, 10, 4200 );
	// scene.fog = new THREE.Fog( 0xc1c1c1, 8, 20 );
	// scene.fog = new THREE.Fog( 0x666666, 2, 15 );

    return scene;
});